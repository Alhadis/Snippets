<?php

class acf_field_FIELD_NAME extends acf_field{

	#	Vars
	var $settings,	#	Will hold info such as directory/path
		$defaults;	#	Will hold default field options


	/**
	 *	Set name/label needed for actions/filters
	 *
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function __construct(){

		#	Vars
		$this->name		=	'FIELD_NAME';
		$this->label	=	__('FIELD_LABEL');
		$this->category	=	__('Basic', 'acf');		#	Basic, Content, Choice, etc
		$this->defaults	=	array(
			#	Add default here to merge into your field. 
			#	This makes things easier when creating the field options as you don't need to use any if( isset('') ) logic.
			#	E.g., 'preview_size' => 'thumbnail'
		);



		parent::__construct();
		
		
		#	Settings
		$this->settings = array(
			'path'		=>	apply_filters('acf/helpers/get_path',	__FILE__),
			'dir'		=>	apply_filters('acf/helpers/get_dir',	__FILE__),
			'version'	=>	'1.0.0'
		);
	}


	/**
	 *	Create extra options for your field. This is rendered when editing a field.
	 *	The value of $field['name'] can be used (like below) to save extra data to the $field
	 *
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 *	@param	$field - an array holding all the field's data
	 */
	function create_options($field){
		#	Defaults?
		/*
			$field = array_merge($this->defaults, $field);
		*/


		#	Key is needed in the field names to correctly save the data
		$key = $field['name'];
		
		
		#	Create field options HTML
		?>
<tr class="field_option field_option_<?php echo $this->name; ?>">
	<td class="label">
		<label><?php _e("Preview Size", 'acf'); ?></label>
		<p class="description"><?php _e("Thumbnail is advised", 'acf'); ?></p>
	</td>

	<td>
		<?php

		do_action('acf/create_field', array(
			'type'		=>	'radio',
			'name'		=>	'fields['.$key.'][preview_size]',
			'value'		=>	$field['preview_size'],
			'layout'	=>	'horizontal',
			'choices'	=>	array(
				'thumbnail' => __('Thumbnail'),
				'something_else' => __('Something Else'),
			)
		));
		?> 
	</td>
</tr>
		<?php
	}


	/**
	 *	Create the HTML interface for your field
	 *
	 *	@param	$field - an array holding all the field's data
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function create_field($field){
		// defaults?
		/*
		$field = array_merge($this->defaults, $field);
		*/
		
		// perhaps use $field['preview_size'] to alter the markup?
		
		
		// create Field HTML
		?>
		<div>
			
		</div>
		<?php
	}
	
	
	/**
	 *	This action is called in the admin_enqueue_scripts action on the edit screen where your field is created.
	 *	Use this action to add CSS + JavaScript to assist your create_field() action.
	 *
	 *	$info	http://codex.wordpress.org/Plugin_API/Action_Reference/admin_enqueue_scripts
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function input_admin_enqueue_scripts(){
		// Note: This function can be removed if not used
		
		
		// register ACF scripts
		wp_register_script( 'acf-input-FIELD_NAME', $this->settings['dir'] . 'js/input.js', array('acf-input'), $this->settings['version'] );
		wp_register_style( 'acf-input-FIELD_NAME', $this->settings['dir'] . 'css/input.css', array('acf-input'), $this->settings['version'] ); 
		
		
		// scripts
		wp_enqueue_script(array(
			'acf-input-FIELD_NAME',	
		));

		// styles
		wp_enqueue_style(array(
			'acf-input-FIELD_NAME',	
		));
	}


	/**
	 *	This action is called in the admin_head action on the edit screen where your field is created.
	 *	Use this action to add CSS and JavaScript to assist your create_field() action.
	 *
	 *	@info	http://codex.wordpress.org/Plugin_API/Action_Reference/admin_head
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function input_admin_head(){
		// Note: This function can be removed if not used
	}
	
	
	/**
	 *	This action is called in the admin_enqueue_scripts action on the edit screen where your field is edited.
	 *	Use this action to add CSS + JavaScript to assist your create_field_options() action.
	 *
	 *	$info	http://codex.wordpress.org/Plugin_API/Action_Reference/admin_enqueue_scripts
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function field_group_admin_enqueue_scripts(){
		// Note: This function can be removed if not used
	}

	
	/**
	 *	This action is called in the admin_head action on the edit screen where your field is edited.
	 *	Use this action to add CSS and JavaScript to assist your create_field_options() action.
	 *
	 *	@info	http://codex.wordpress.org/Plugin_API/Action_Reference/admin_head
	 *	@type	action
	 *	@since	3.6
	 *	@date	2013-01-23
	 */
	function field_group_admin_head(){
		// Note: This function can be removed if not used
	}


	/**
	 *	This filter is applied to the $value after it is loaded from the db
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *
	 *	@param	$value - the value found in the database
	 *	@param	$post_id - the $post_id from which the value was loaded
	 *	@param	$field - the field array holding all the field options
	 *
	 *	@return	$value - the value to be saved in the database
	 */
	function load_value($value, $post_id, $field){
		// Note: This function can be removed if not used
		return $value;
	}
	
	
	/**
	 *	This filter is applied to the $value before it is updated in the db
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *
	 *	@param	$value - the value which will be saved in the database
	 *	@param	$post_id - the $post_id of which the value will be saved
	 *	@param	$field - the field array holding all the field options
	 *	@return	$value - the modified value
	 */
	function update_value($value, $post_id, $field){
		// Note: This function can be removed if not used
		$this->format_value();
		$this->update_value();
		return $value;
	}
	
	
	/**
	 *	This filter is applied to the $value after it is loaded from the db and before it is passed to the create_field action
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *
	 *	@param	$value - The value which was loaded from the database
	 *	@param	$post_id - The $post_id from which the value was loaded
	 *	@param	$field - The field array holding all the field options
	 *	@return	$value - The modified value
	 */
	function format_value($value, $post_id, $field){
		// defaults?
		/*
		$field = array_merge($this->defaults, $field);
		*/
		
		// perhaps use $field['preview_size'] to alter the $value?
		
		
		// Note: This function can be removed if not used
		return $value;
	}
	
	
	/**
	 *	This filter is applied to the $value after it is loaded from the db and before it is passed back to the API functions such as the_field
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *
	 *	@param	$value - the value which was loaded from the database
	 *	@param	$post_id - the $post_id from which the value was loaded
	 *	@param	$field - the field array holding all the field options
	 *
	 *	@return	$value - the modified value
	 */
	function format_value_for_api($value, $post_id, $field){
		// defaults?
		/*
		$field = array_merge($this->defaults, $field);
		*/
		
		// perhaps use $field['preview_size'] to alter the $value?
		
		
		// Note: This function can be removed if not used
		return $value;
	}
	
	
	/**
	 *	This filter is applied to the $field after it is loaded from the database
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *	@param	$field - the field array holding all the field options
	 *	@return	$field - the field array holding all the field options
	 */
	function load_field($field){
		// Note: This function can be removed if not used
		return $field;
	}
	
	
	/**
	 *	This filter is applied to the $field before it is saved to the database
	 *
	 *	@type	filter
	 *	@since	3.6
	 *	@date	2013-01-23
	 *
	 *	@param	$field - the field array holding all the field options
	 *	@param	$post_id - the field group ID (post_type = acf)
	 *	@return	$field - the modified field
	 */
	function update_field($field, $post_id){
		// Note: This function can be removed if not used
		return $field;
	}
}


#	Create field
new acf_field_FIELD_NAME();