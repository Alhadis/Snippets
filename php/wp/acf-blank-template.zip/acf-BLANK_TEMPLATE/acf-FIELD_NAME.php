<?php

/*
	Plugin Name: Advanced Custom Fields: FIELD_NAME
	Description: FIELD_DESCRIPTION
	Version: 1.0.0
	Author: AUTHOR_NAME
	Author URI: AUTHOR_URI
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/



#	1. set text domain
#	Reference: https://codex.wordpress.org/Function_Reference/load_plugin_textdomain
load_plugin_textdomain('acf-FIELD_NAME', false, dirname(plugin_basename(__FILE__)) . '/lang/');


function register_fields_FIELD_NAME(){
	include_once('acf-FIELD_NAME-v4.php');
}

add_action('acf/register_fields', 'register_fields_FIELD_NAME');
